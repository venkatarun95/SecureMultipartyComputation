package it.unisa.dia.gas.jpbc.benchmark;

/**
 * @author Angelo De Caro (jpbclib@gmail.com)
 */
public interface Benchmark {

    String toHTML();

}
